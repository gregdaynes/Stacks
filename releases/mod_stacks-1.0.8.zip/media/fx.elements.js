/*
 * script		Fx.Elements.js
 * description	Effect to change any number of CSS properties of any number of Elements.
 * license		MIT-style license
 * author		Valerio Proietti
 * requires		core:1.2.4
 *				Fx.CSS
 *				MooTools.More
 * provides		[Fx.Elements]
 */
Fx.Elements=new Class({Extends:Fx.CSS,initialize:function(b,a){this.elements=this.subject=$$(b);this.parent(a)},compute:function(g,h,j){var c={};for(var d in g){var a=g[d],e=h[d],f=c[d]={};for(var b in a){f[b]=this.parent(a[b],e[b],j)}}return c},set:function(b){for(var c in b){var a=b[c];for(var d in a){this.render(this.elements[c],d,a[d],this.options.unit)}}return this},start:function(c){if(!this.check(c)){return this}var h={},j={};for(var d in c){var f=c[d],a=h[d]={},g=j[d]={};for(var b in f){var e=this.prepare(this.elements[d],b,f[b]);a[b]=e.from;g[b]=e.to}}return this.parent(h,j)}});