/*
 * script		Loop.js
 * description	Runs a class method on a periodical
 * license		MIT-style license.
 * authors		Ryan Florence <http://ryanflorence.com>
 * docs			http://moodocs.net/rpflo/mootools-rpflo/Loop
 * requires		core:1.2.4/'*'
 * provides		[Loop]
 */
var Loop=new Class({loopCount:0,isStopped:true,isLooping:false,loopMethod:$empty,setLoop:function(b,a){if(this.isLooping){this.stopLoop();var c=true}else{var c=false}this.loopMethod=b;this.loopDelay=a||3000;if(c){this.startLoop()}return this},stopLoop:function(){this.isStopped=true;this.isLooping=false;$clear(this.periodical);return this},startLoop:function(a){if(this.isStopped){var a=(a)?a:this.loopDelay;this.isStopped=false;this.isLooping=true;this.periodical=this.looper.periodical(a,this)}return this},resetLoop:function(){this.loopCount=0;return this},looper:function(){this.loopCount++;this.loopMethod(this.loopCount);return this}});